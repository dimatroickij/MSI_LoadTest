SearchPointInRegistry()
{

	web_set_user("sysadmin", 
		lr_unmask("601021dee"), 
		"192.168.109.240:80");

	web_add_auto_header("DNT", 
		"1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("192.168.109.240", 
		"URL=http://192.168.109.240/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t182.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/assets/fonts/roboto/roboto.css", ENDITEM, 
		"Url=/styles.206c321067b55e6a4b75.css", ENDITEM, 
		"Url=/assets/fonts/fontawesome/css/all.css", ENDITEM, 
		"Url=/runtime.acf0dec4155e77772545.js", ENDITEM, 
		"Url=/polyfills.9cfb3f513e777138fb2c.js", ENDITEM, 
		"Url=/main.f260e358d880bc7956b9.js", ENDITEM, 
		"Url=/assets/images/logo.svg", ENDITEM, 
		LAST);

	web_set_sockets_option("SSL_VERSION", "2&3");

	web_url("configuration.json", 
		"URL=http://192.168.109.240//configurations/configuration.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.109.240/", 
		"Snapshot=t183.inf", 
		"Mode=HTML", 
		LAST);

	web_url("default.css", 
		"URL=http://192.168.109.240/themes/default.css", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://192.168.109.240/", 
		"Snapshot=t184.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=../assets/fonts/roboto/roboto-v20-latin_cyrillic-regular.woff2", "Referer=http://192.168.109.240/assets/fonts/roboto/roboto.css", ENDITEM, 
		"Url=../assets/fonts/fontawesome/webfonts/fa-light-300.woff2", "Referer=http://192.168.109.240/assets/fonts/fontawesome/css/all.css", ENDITEM, 
		"Url=../assets/fonts/roboto/roboto-v20-latin_cyrillic-500.woff2", "Referer=http://192.168.109.240/assets/fonts/roboto/roboto.css", ENDITEM, 
		"Url=../assets/fonts/roboto/roboto-v20-latin_cyrillic-700.woff2", "Referer=http://192.168.109.240/assets/fonts/roboto/roboto.css", ENDITEM, 
		LAST);

	/*Connection ID 0 received buffer WebSocketReceive0*/

	/*Connection ID 1 received buffer WebSocketReceive1*/

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("platform-admin-ui", 
		"URL=http://192.168.109.240/internal/platform-admin-ui", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://192.168.109.240/", 
		"Snapshot=t185.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=platform-admin-ui/runtime.b9759be94b30ae2a33e0.js", "Referer=http://192.168.109.240/internal/platform-admin-ui/", ENDITEM, 
		"Url=platform-admin-ui/vendor.6597440179a1a361a262.js", "Referer=http://192.168.109.240/internal/platform-admin-ui/", ENDITEM, 
		"Url=platform-admin-ui/main.a113815411d365738099.js", "Referer=http://192.168.109.240/internal/platform-admin-ui/", ENDITEM, 
		"Url=platform-admin-ui/styles.934e1211369de65239dc.css", "Referer=http://192.168.109.240/internal/platform-admin-ui/", ENDITEM, 
		"Url=platform-admin-ui/polyfills.cfc88ca87321ca8e8ec7.js", "Referer=http://192.168.109.240/internal/platform-admin-ui/", ENDITEM, 
		"Url=platform-admin-ui/themes/default/theme.css", "Referer=http://192.168.109.240/internal/platform-admin-ui/", ENDITEM, 
		"Url=platform-admin-ui/common.f69f8709d30822f7fa9b.js", "Referer=http://192.168.109.240/internal/platform-admin-ui/", ENDITEM, 
		"Url=platform-admin-ui/25.d6516b342757454e33d9.js", "Referer=http://192.168.109.240/internal/platform-admin-ui/", ENDITEM, 
		"Url=platform-admin-ui/11.c02acfdbffc46255fbeb.js", "Referer=http://192.168.109.240/internal/platform-admin-ui/", ENDITEM, 
		"Url=platform-admin-ui/themes/default/images/default-spinner.svg", "Referer=http://192.168.109.240/internal/platform-admin-ui/", ENDITEM, 
		"Url=platform-admin-ui/3.c4a949ba0a212384bfec.js", "Referer=http://192.168.109.240/internal/platform-admin-ui/", ENDITEM, 
		"Url=platform-admin-ui/2.1891a41e4a0f084937e0.js", "Referer=http://192.168.109.240/internal/platform-admin-ui/", ENDITEM, 
		"Url=platform-admin-ui/4.842d7f0dccf6876ffcfc.js", "Referer=http://192.168.109.240/internal/platform-admin-ui/", ENDITEM, 
		"Url=platform-admin-ui/12.416582247b9526f72da2.js", "Referer=http://192.168.109.240/internal/platform-admin-ui/", ENDITEM, 
		LAST);

	web_url("configuration.json_2", 
		"URL=http://192.168.109.240/internal/platform-admin-ui//configurations/configuration.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.109.240/internal/platform-admin-ui/", 
		"Snapshot=t186.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/internal/platform-admin-ui/themes/default/fonts/ptsans.css", "Referer=http://192.168.109.240/internal/platform-admin-ui/themes/default/theme.css", ENDITEM, 
		"Url=/internal/platform-admin-ui/themes/default/fonts/ptsans/ptsansbold.woff2", "Referer=http://192.168.109.240/internal/platform-admin-ui/themes/default/fonts/ptsans.css", ENDITEM, 
		"Url=/internal/platform-admin-ui/themes/default/fonts/ptsans/ptsans.woff2", "Referer=http://192.168.109.240/internal/platform-admin-ui/themes/default/fonts/ptsans.css", ENDITEM, 
		LAST);

	/*Possible OAUTH authorization was detected. It is recommended to correlate the authorization parameters.*/

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("login", 
		"URL=http://192.168.109.240/internal/authutil/auth/login?returnUrl=http://192.168.109.240/internal/platform-admin-ui/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://192.168.109.240/internal/platform-admin-ui/", 
		"Snapshot=t187.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=../runtime.912d0e53e8715a3eb26c.js", "Referer=http://192.168.109.240/internal/authutil/auth/login?returnUrl=http://192.168.109.240/internal/platform-admin-ui/", ENDITEM, 
		"Url=../styles.441d4b6bb0d262a7576b.css", "Referer=http://192.168.109.240/internal/authutil/auth/login?returnUrl=http://192.168.109.240/internal/platform-admin-ui/", ENDITEM, 
		"Url=../polyfills.adc7784a1251bb58b248.js", "Referer=http://192.168.109.240/internal/authutil/auth/login?returnUrl=http://192.168.109.240/internal/platform-admin-ui/", ENDITEM, 
		"Url=../main.81b056e6adee1957fff7.js", "Referer=http://192.168.109.240/internal/authutil/auth/login?returnUrl=http://192.168.109.240/internal/platform-admin-ui/", ENDITEM, 
		LAST);

	web_url("configuration.json_3", 
		"URL=http://192.168.109.240/internal/authutil//configurations/configuration.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.109.240/internal/authutil/auth/login?returnUrl=http://192.168.109.240/internal/platform-admin-ui/", 
		"Snapshot=t188.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/internal/authutil/themes/default/theme.css", "Referer=http://192.168.109.240/internal/authutil/auth/login?returnUrl=http://192.168.109.240/internal/platform-admin-ui/", ENDITEM, 
		"Url=/internal/authutil/5.aaabecb7b2435b372cd5.js", "Referer=http://192.168.109.240/internal/authutil/auth/login?returnUrl=http://192.168.109.240/internal/platform-admin-ui/", ENDITEM, 
		"Url=/internal/authutil/themes/default/images/default-logo.svg", "Referer=http://192.168.109.240/internal/authutil/", ENDITEM, 
		"Url=/internal/authutil/themes/default/fonts/roboto/roboto-v20-latin_cyrillic-regular.woff2", "Referer=http://192.168.109.240/internal/authutil/themes/default/theme.css", ENDITEM, 
		"Url=/internal/authutil/themes/default/fonts/roboto/roboto-v20-latin_cyrillic-500.woff2", "Referer=http://192.168.109.240/internal/authutil/themes/default/theme.css", ENDITEM, 
		"Url=/internal/authutil/MaterialIcons-Regular.12a47ed5fd5585f0f422.woff2", "Referer=http://192.168.109.240/internal/authutil/styles.441d4b6bb0d262a7576b.css", ENDITEM, 
		LAST);

	web_set_sockets_option("INITIAL_AUTH", "BASIC");

	web_add_header("Origin", 
		"http://192.168.109.240");

	web_custom_request("auth", 
		"URL=http://192.168.109.240/internal/auth/authenticator/api/internalauth/auth?loaderKey=default", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.109.240/internal/authutil/auth/login?returnUrl=http:%2F%2F192.168.109.240%2Finternal%2Fplatform-admin-ui%2F", 
		"Snapshot=t189.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_url("extended-profile", 
		"URL=http://192.168.109.240/internal/api/current-user-manager/api/current/extended-profile?loaderKey=default", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.109.240/internal/authutil/auth/login?returnUrl=http:%2F%2F192.168.109.240%2Finternal%2Fplatform-admin-ui%2F", 
		"Snapshot=t190.inf", 
		"Mode=HTML", 
		LAST);

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("platform-admin-ui_2", 
		"URL=http://192.168.109.240/internal/platform-admin-ui/", 
		"Resource=0", 
		"Referer=http://192.168.109.240/internal/authutil/auth/login?returnUrl=http:%2F%2F192.168.109.240%2Finternal%2Fplatform-admin-ui%2F", 
		"Snapshot=t191.inf", 
		"Mode=HTML", 
		LAST);

	web_url("__check_session", 
		"URL=http://192.168.109.240/internal/api/__check_session", 
		"Resource=0", 
		"Referer=http://192.168.109.240/internal/platform-admin-ui/", 
		"Snapshot=t192.inf", 
		"Mode=HTML", 
		LAST);

	web_url("statuses", 
		"URL=http://192.168.109.240/internal/api/access-manager/api/userprofiles/statuses?loaderKey=default", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.109.240/internal/platform-admin-ui/access-control/profiles", 
		"Snapshot=t193.inf", 
		"Mode=HTML", 
		LAST);

	web_url("DisplaySnils", 
		"URL=http://192.168.109.240/internal/api/access-manager/api/systemsettings/GUI/DisplaySnils?loaderKey=none", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.109.240/internal/platform-admin-ui/access-control/profiles", 
		"Snapshot=t194.inf", 
		"Mode=HTML", 
		LAST);

	web_url("UserProfile", 
		"URL=http://192.168.109.240/internal/api/access-manager/api/supplementary-attribute-refs/UserProfile?limit=-1&loaderKey=default", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.109.240/internal/platform-admin-ui/access-control/profiles", 
		"Snapshot=t195.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/internal/platform-admin-ui/themes/default/images/default-logo.svg", "Referer=http://192.168.109.240/internal/platform-admin-ui/styles.934e1211369de65239dc.css", ENDITEM, 
		LAST);

	web_url("extended-profile_2", 
		"URL=http://192.168.109.240/internal/api/current-user-manager/api/current/extended-profile?loaderKey=default", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.109.240/internal/platform-admin-ui/access-control/profiles", 
		"Snapshot=t196.inf", 
		"Mode=HTML", 
		LAST);

	web_url("userprofiles", 
		"URL=http://192.168.109.240/internal/api/access-manager/api/userprofiles?status=ACTIVE&offset=0&limit=10&order_by=asc(snils)&loaderKey=de39ec16-4808-4ee7-8286-f0d278d83b39", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.109.240/internal/platform-admin-ui/access-control/profiles", 
		"Snapshot=t197.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/internal/platform-admin-ui/10.6c2a78fa0539eee91dee.js", "Referer=http://192.168.109.240/internal/platform-admin-ui/access-control/profiles", ENDITEM, 
		"Url=/internal/platform-admin-ui/21.ae3097ef9130c397449d.js", "Referer=http://192.168.109.240/internal/platform-admin-ui/access-control/profiles", ENDITEM, 
		LAST);

	web_url("serviceclsitems", 
		"URL=http://192.168.109.240/internal/api/access-manager/api/serviceclsitems?limit=-1&loaderKey=ae0cc563-7340-4eb9-991c-73980bd7a54d", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.109.240/internal/platform-admin-ui/services/endpoints", 
		"Snapshot=t198.inf", 
		"Mode=HTML", 
		LAST);

	web_url("endpoints", 
		"URL=http://192.168.109.240/internal/api/access-manager/api/endpoints?offset=0&limit=10&order_by=asc(sysname)&loaderKey=eedd3e80-acb8-4769-a407-63405ca3b65f", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.109.240/internal/platform-admin-ui/services/endpoints", 
		"Snapshot=t199.inf", 
		"Mode=HTML", 
		LAST);

	lr_think_time(5);

	web_url("endpoints_2", 
		"URL=http://192.168.109.240/internal/api/access-manager/api/endpoints?offset=0&limit=10&order_by=asc(sysname)&loaderKey=a1e5473e-ab79-4adf-a20d-109f78f6c908", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.109.240/internal/platform-admin-ui/services/endpoints", 
		"Snapshot=t200.inf", 
		"Mode=HTML", 
		LAST);

	web_url("endpoints_3", 
		"URL=http://192.168.109.240/internal/api/access-manager/api/endpoints?sysname=a&offset=0&limit=10&order_by=asc(sysname)&loaderKey=a1e5473e-ab79-4adf-a20d-109f78f6c908", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.109.240/internal/platform-admin-ui/services/endpoints", 
		"Snapshot=t201.inf", 
		"Mode=HTML", 
		LAST);

	web_url("endpoints_4", 
		"URL=http://192.168.109.240/internal/api/access-manager/api/endpoints?sysname=ad&offset=0&limit=10&order_by=asc(sysname)&loaderKey=a1e5473e-ab79-4adf-a20d-109f78f6c908", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.109.240/internal/platform-admin-ui/services/endpoints", 
		"Snapshot=t202.inf", 
		"Mode=HTML", 
		LAST);

	web_url("endpoints_5", 
		"URL=http://192.168.109.240/internal/api/access-manager/api/endpoints?sysname=add&offset=0&limit=10&order_by=asc(sysname)&loaderKey=a1e5473e-ab79-4adf-a20d-109f78f6c908", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.109.240/internal/platform-admin-ui/services/endpoints", 
		"Snapshot=t203.inf", 
		"Mode=HTML", 
		LAST);

	web_url("endpoints_6", 
		"URL=http://192.168.109.240/internal/api/access-manager/api/endpoints?sysname=add&offset=0&limit=10&order_by=asc(sysname)&loaderKey=eedd3e80-acb8-4769-a407-63405ca3b65f", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.109.240/internal/platform-admin-ui/services/endpoints", 
		"Snapshot=t204.inf", 
		"Mode=HTML", 
		LAST);

	return 0;
}