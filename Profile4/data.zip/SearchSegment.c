SearchSegment()
{

	web_set_user("sysadmin", 
		lr_unmask("60101114e"), 
		"192.168.109.240:80");

	web_add_auto_header("DNT", 
		"1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("192.168.109.240", 
		"URL=http://192.168.109.240/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t138.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/styles.206c321067b55e6a4b75.css", ENDITEM, 
		"Url=/assets/fonts/roboto/roboto.css", ENDITEM, 
		"Url=/assets/fonts/fontawesome/css/all.css", ENDITEM, 
		"Url=/runtime.acf0dec4155e77772545.js", ENDITEM, 
		"Url=/polyfills.9cfb3f513e777138fb2c.js", ENDITEM, 
		"Url=/main.f260e358d880bc7956b9.js", ENDITEM, 
		"Url=/assets/images/logo.svg", ENDITEM, 
		LAST);

	web_set_sockets_option("SSL_VERSION", "2&3");

	/*Possible OAUTH authorization was detected. It is recommended to correlate the authorization parameters.*/

	web_add_cookie("font_loaded=YSv1; DOMAIN=yandex.ru");

	web_add_cookie("_ym_uid=1573805452443910168; DOMAIN=yandex.ru");

	web_add_cookie("mda=0; DOMAIN=yandex.ru");

	web_add_cookie("yandexuid=8320292071573805450; DOMAIN=yandex.ru");

	web_add_cookie("yuidss=8320292071573805450; DOMAIN=yandex.ru");

	web_add_cookie("my=YwA=; DOMAIN=yandex.ru");

	web_add_cookie("Secure_session_id=1580114580.0.1.160061779.0.170906.49402.f7f5fe9e80c38883846057c915ff3935; DOMAIN=yandex.ru");

	web_add_cookie("_csrf=c47oTgAW6wEQRGVjGIfzK28R; DOMAIN=yandex.ru");

	web_add_cookie("gdpr=0; DOMAIN=yandex.ru");

	web_add_cookie("ymex=1896327882.yrts.1580967882#1900932202.yrtsi.1585572202; DOMAIN=yandex.ru");

	web_add_cookie("L=WnVGfUVde2haX0wHbERbAwBeYQ98cAp4EgcDKxoUDggnGRkD.1587546665.14211.39533.f96b7e9a736873a0ad3f29c40a2f5ba1; DOMAIN=yandex.ru");

	web_add_cookie("yandex_login=dimatroickij; DOMAIN=yandex.ru");

	web_add_cookie("yabs-sid=1075465931599135955; DOMAIN=yandex.ru");

	web_add_cookie("is_gdpr=0; DOMAIN=yandex.ru");

	web_add_cookie("is_gdpr_b=CKjwdxDrAygC; DOMAIN=yandex.ru");

	web_add_cookie("tuid=a:4d8369d5f7368b27e4e309838ccb63fdcdc698f85e3001482c74fa3c50100270; DOMAIN=yandex.ru");

	web_add_cookie("yandex_gid=20523; DOMAIN=yandex.ru");

	web_add_cookie("i=NkvK69WvNa4qIeZkcd+hTwGh+0M9gLwuU3QAcyn9aUOQ6vnFLKLFcdlYMv4VPdyr656SwObZuUbTp2XbGjxJ4ZMeCto=; DOMAIN=yandex.ru");

	web_add_cookie("hcxWnzbUzfz=1; DOMAIN=yandex.ru");

	web_add_cookie("bltsr=1; DOMAIN=yandex.ru");

	web_add_cookie("instruction=1; DOMAIN=yandex.ru");

	web_add_cookie("Session_id=3:1611408703.5.0.1574245027415:TCDCuQ:56.1|46814245.5608957.2.2:5608957|1130000034225354.5609733.2.2:5609733|229203.475964.FTdKX1aPT221iJuikaHdZ2zOCIU; DOMAIN=yandex.ru");

	web_add_cookie("sessionid2=3:1611408703.5.0.1574245027415:TCDCuQ:56.1|46814245.5608957.2.2:5608957|1130000034225354.5609733.2.2:5609733|229203.946113.CEZwh9zbcrnRS9rgwIeTkLtLJ50; DOMAIN=yandex.ru");

	web_add_cookie("_ym_d=1611560677; DOMAIN=yandex.ru");

	web_add_cookie("yabs-frequency=/5/00090000001t4PHU/mWTpS9G0000eFo7NRx1mbG0002W_GUpvSd2K0000A3_1xasmS9K0000eFq0JTx1mbG0002a_u07BLB1mbG0002W_8B9si72L0000AJz00hPsi72L0000A3-WIdUmS9K0000eFo0DTx1mbG0002W_GBzPi72L0000AJy01TDni7000000A3yWODGzRG00000eFo2OJ3vj000002W_81XrFMq00000A3zWVbMmS000000eFo3MMB1m000002W_O000/; DOMAIN=yandex.ru");

	web_add_cookie("yp=1618916268.nt.computers#1623882458.szm.1%3A1920x1080%3A1920x937#1902906665.udn.cDrQlNC80LjRgtGA0LjQuSDQotGA0L7QuNGG0LrQuNC5#1902906661.multib.1#1902906661.2fa.1#1643100753.p_sw.1611564752#1614157767.los.1#1614157767.losc.0#1612939175.ygu.1#1611919682.zmblt.1369#1611919682.zmbbr.chrome%3A87_0_4280_141; DOMAIN=yandex.ru");

	web_add_cookie("ys=musicchrome.0-0-471111111111111111111111111111111111111111#udn.cDrQlNC80LjRgtGA0LjQuSDQotGA0L7QuNGG0LrQuNC5#wprid.1611565705211134-913433884460681887400180-production-app-host-sas-web-yp-63#c_chck.310002396; DOMAIN=yandex.ru");

	web_url("configuration.json", 
		"URL=http://192.168.109.240//configurations/configuration.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.109.240/", 
		"Snapshot=t139.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://yandex.ru/clck/click/dtype=elduse/path=tech.yaelements.dayuse/vars=-dayuse=438,-bro=chrome,-productname=weatherchrome,-ver=8-22-3,-ui=%7B09DD5623-D941-75FB-FF65-BEE4E3B516BA%7D,-brandID=yandex,-clid1=2231762/slots=0,0,0/*", "Referer=", ENDITEM, 
		LAST);

	/*Connection ID 0 received buffer WebSocketReceive0*/

	web_url("default.css", 
		"URL=http://192.168.109.240/themes/default.css", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://192.168.109.240/", 
		"Snapshot=t140.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=../assets/fonts/roboto/roboto-v20-latin_cyrillic-regular.woff2", "Referer=http://192.168.109.240/assets/fonts/roboto/roboto.css", ENDITEM, 
		"Url=../assets/fonts/roboto/roboto-v20-latin_cyrillic-700.woff2", "Referer=http://192.168.109.240/assets/fonts/roboto/roboto.css", ENDITEM, 
		"Url=../assets/fonts/roboto/roboto-v20-latin_cyrillic-500.woff2", "Referer=http://192.168.109.240/assets/fonts/roboto/roboto.css", ENDITEM, 
		"Url=../assets/fonts/fontawesome/webfonts/fa-light-300.woff2", "Referer=http://192.168.109.240/assets/fonts/fontawesome/css/all.css", ENDITEM, 
		LAST);

	/*Connection ID 1 received buffer WebSocketReceive1*/

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("platform-admin-ui", 
		"URL=http://192.168.109.240/internal/platform-admin-ui", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://192.168.109.240/", 
		"Snapshot=t141.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=platform-admin-ui/runtime.b9759be94b30ae2a33e0.js", "Referer=http://192.168.109.240/internal/platform-admin-ui/", ENDITEM, 
		"Url=platform-admin-ui/vendor.6597440179a1a361a262.js", "Referer=http://192.168.109.240/internal/platform-admin-ui/", ENDITEM, 
		"Url=platform-admin-ui/main.a113815411d365738099.js", "Referer=http://192.168.109.240/internal/platform-admin-ui/", ENDITEM, 
		"Url=platform-admin-ui/styles.934e1211369de65239dc.css", "Referer=http://192.168.109.240/internal/platform-admin-ui/", ENDITEM, 
		"Url=platform-admin-ui/polyfills.cfc88ca87321ca8e8ec7.js", "Referer=http://192.168.109.240/internal/platform-admin-ui/", ENDITEM, 
		"Url=platform-admin-ui/themes/default/theme.css", "Referer=http://192.168.109.240/internal/platform-admin-ui/", ENDITEM, 
		"Url=platform-admin-ui/25.d6516b342757454e33d9.js", "Referer=http://192.168.109.240/internal/platform-admin-ui/", ENDITEM, 
		"Url=platform-admin-ui/common.f69f8709d30822f7fa9b.js", "Referer=http://192.168.109.240/internal/platform-admin-ui/", ENDITEM, 
		"Url=platform-admin-ui/themes/default/images/default-spinner.svg", "Referer=http://192.168.109.240/internal/platform-admin-ui/", ENDITEM, 
		"Url=platform-admin-ui/11.c02acfdbffc46255fbeb.js", "Referer=http://192.168.109.240/internal/platform-admin-ui/", ENDITEM, 
		"Url=platform-admin-ui/3.c4a949ba0a212384bfec.js", "Referer=http://192.168.109.240/internal/platform-admin-ui/", ENDITEM, 
		"Url=platform-admin-ui/4.842d7f0dccf6876ffcfc.js", "Referer=http://192.168.109.240/internal/platform-admin-ui/", ENDITEM, 
		"Url=platform-admin-ui/2.1891a41e4a0f084937e0.js", "Referer=http://192.168.109.240/internal/platform-admin-ui/", ENDITEM, 
		"Url=platform-admin-ui/12.416582247b9526f72da2.js", "Referer=http://192.168.109.240/internal/platform-admin-ui/", ENDITEM, 
		LAST);

	web_url("configuration.json_2", 
		"URL=http://192.168.109.240/internal/platform-admin-ui//configurations/configuration.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.109.240/internal/platform-admin-ui/", 
		"Snapshot=t142.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/internal/platform-admin-ui/themes/default/fonts/ptsans.css", "Referer=http://192.168.109.240/internal/platform-admin-ui/themes/default/theme.css", ENDITEM, 
		"Url=/internal/platform-admin-ui/themes/default/fonts/ptsans/ptsansbold.woff2", "Referer=http://192.168.109.240/internal/platform-admin-ui/themes/default/fonts/ptsans.css", ENDITEM, 
		"Url=/internal/platform-admin-ui/themes/default/fonts/ptsans/ptsans.woff2", "Referer=http://192.168.109.240/internal/platform-admin-ui/themes/default/fonts/ptsans.css", ENDITEM, 
		LAST);

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("login", 
		"URL=http://192.168.109.240/internal/authutil/auth/login?returnUrl=http://192.168.109.240/internal/platform-admin-ui/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://192.168.109.240/internal/platform-admin-ui/", 
		"Snapshot=t143.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=../runtime.912d0e53e8715a3eb26c.js", "Referer=http://192.168.109.240/internal/authutil/auth/login?returnUrl=http://192.168.109.240/internal/platform-admin-ui/", ENDITEM, 
		"Url=../styles.441d4b6bb0d262a7576b.css", "Referer=http://192.168.109.240/internal/authutil/auth/login?returnUrl=http://192.168.109.240/internal/platform-admin-ui/", ENDITEM, 
		"Url=../polyfills.adc7784a1251bb58b248.js", "Referer=http://192.168.109.240/internal/authutil/auth/login?returnUrl=http://192.168.109.240/internal/platform-admin-ui/", ENDITEM, 
		"Url=../main.81b056e6adee1957fff7.js", "Referer=http://192.168.109.240/internal/authutil/auth/login?returnUrl=http://192.168.109.240/internal/platform-admin-ui/", ENDITEM, 
		LAST);

	web_url("configuration.json_3", 
		"URL=http://192.168.109.240/internal/authutil//configurations/configuration.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.109.240/internal/authutil/auth/login?returnUrl=http://192.168.109.240/internal/platform-admin-ui/", 
		"Snapshot=t144.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/internal/authutil/themes/default/theme.css", "Referer=http://192.168.109.240/internal/authutil/auth/login?returnUrl=http://192.168.109.240/internal/platform-admin-ui/", ENDITEM, 
		"Url=/internal/authutil/themes/default/images/default-logo.svg", "Referer=http://192.168.109.240/internal/authutil/", ENDITEM, 
		"Url=/internal/authutil/themes/default/fonts/roboto/roboto-v20-latin_cyrillic-500.woff2", "Referer=http://192.168.109.240/internal/authutil/themes/default/theme.css", ENDITEM, 
		"Url=/internal/authutil/5.aaabecb7b2435b372cd5.js", "Referer=http://192.168.109.240/internal/authutil/auth/login?returnUrl=http://192.168.109.240/internal/platform-admin-ui/", ENDITEM, 
		"Url=/internal/authutil/themes/default/fonts/roboto/roboto-v20-latin_cyrillic-regular.woff2", "Referer=http://192.168.109.240/internal/authutil/themes/default/theme.css", ENDITEM, 
		"Url=/internal/authutil/MaterialIcons-Regular.12a47ed5fd5585f0f422.woff2", "Referer=http://192.168.109.240/internal/authutil/styles.441d4b6bb0d262a7576b.css", ENDITEM, 
		LAST);

	web_set_sockets_option("INITIAL_AUTH", "BASIC");

	web_add_header("Origin", 
		"http://192.168.109.240");

	web_custom_request("auth", 
		"URL=http://192.168.109.240/internal/auth/authenticator/api/internalauth/auth?loaderKey=default", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.109.240/internal/authutil/auth/login?returnUrl=http:%2F%2F192.168.109.240%2Finternal%2Fplatform-admin-ui%2F", 
		"Snapshot=t145.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_url("extended-profile", 
		"URL=http://192.168.109.240/internal/api/current-user-manager/api/current/extended-profile?loaderKey=default", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.109.240/internal/authutil/auth/login?returnUrl=http:%2F%2F192.168.109.240%2Finternal%2Fplatform-admin-ui%2F", 
		"Snapshot=t146.inf", 
		"Mode=HTML", 
		LAST);

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("platform-admin-ui_2", 
		"URL=http://192.168.109.240/internal/platform-admin-ui/", 
		"Resource=0", 
		"Referer=http://192.168.109.240/internal/authutil/auth/login?returnUrl=http:%2F%2F192.168.109.240%2Finternal%2Fplatform-admin-ui%2F", 
		"Snapshot=t147.inf", 
		"Mode=HTML", 
		LAST);

	web_url("__check_session", 
		"URL=http://192.168.109.240/internal/api/__check_session", 
		"Resource=0", 
		"Referer=http://192.168.109.240/internal/platform-admin-ui/", 
		"Snapshot=t148.inf", 
		"Mode=HTML", 
		LAST);

	web_url("statuses", 
		"URL=http://192.168.109.240/internal/api/access-manager/api/userprofiles/statuses?loaderKey=default", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.109.240/internal/platform-admin-ui/access-control/profiles", 
		"Snapshot=t149.inf", 
		"Mode=HTML", 
		LAST);

	web_url("DisplaySnils", 
		"URL=http://192.168.109.240/internal/api/access-manager/api/systemsettings/GUI/DisplaySnils?loaderKey=none", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.109.240/internal/platform-admin-ui/access-control/profiles", 
		"Snapshot=t150.inf", 
		"Mode=HTML", 
		LAST);

	web_url("UserProfile", 
		"URL=http://192.168.109.240/internal/api/access-manager/api/supplementary-attribute-refs/UserProfile?limit=-1&loaderKey=default", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.109.240/internal/platform-admin-ui/access-control/profiles", 
		"Snapshot=t151.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/internal/platform-admin-ui/themes/default/images/default-logo.svg", "Referer=http://192.168.109.240/internal/platform-admin-ui/styles.934e1211369de65239dc.css", ENDITEM, 
		LAST);

	web_url("extended-profile_2", 
		"URL=http://192.168.109.240/internal/api/current-user-manager/api/current/extended-profile?loaderKey=default", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.109.240/internal/platform-admin-ui/access-control/profiles", 
		"Snapshot=t152.inf", 
		"Mode=HTML", 
		LAST);

	web_url("userprofiles", 
		"URL=http://192.168.109.240/internal/api/access-manager/api/userprofiles?status=ACTIVE&offset=0&limit=10&order_by=asc(snils)&loaderKey=68e1a3b6-a2de-4de4-9e6c-b79d2529b156", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.109.240/internal/platform-admin-ui/access-control/profiles", 
		"Snapshot=t153.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/internal/platform-admin-ui/10.6c2a78fa0539eee91dee.js", "Referer=http://192.168.109.240/internal/platform-admin-ui/access-control/profiles", ENDITEM, 
		"Url=/internal/platform-admin-ui/24.fa7dfda29de4130088fb.js", "Referer=http://192.168.109.240/internal/platform-admin-ui/access-control/profiles", ENDITEM, 
		LAST);

	web_url("serviceclsitems", 
		"URL=http://192.168.109.240/internal/api/access-manager/api/serviceclsitems?limit=-1&order_by=asc(name)&loaderKey=4c2f4dd2-5981-4819-8ff1-8b9ba4e9a12e", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.109.240/internal/platform-admin-ui/services/services", 
		"Snapshot=t154.inf", 
		"Mode=HTML", 
		LAST);

	web_url("servicerefs", 
		"URL=http://192.168.109.240/internal/api/access-manager/api/servicerefs?offset=0&limit=10&order_by=asc(name)&loaderKey=d177ced5-90b4-47e8-909a-2fb1ea46cbac", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.109.240/internal/platform-admin-ui/services/services", 
		"Snapshot=t155.inf", 
		"Mode=HTML", 
		LAST);

	lr_think_time(4);

	web_url("9c9229c7-8a3f-4dfc-9cd0-966d5af19acc", 
		"URL=http://192.168.109.240/internal/api/access-manager/api/servicerefs/9c9229c7-8a3f-4dfc-9cd0-966d5af19acc?loaderKey=none", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.109.240/internal/platform-admin-ui/services/services/9c9229c7-8a3f-4dfc-9cd0-966d5af19acc", 
		"Snapshot=t156.inf", 
		"Mode=HTML", 
		LAST);

	web_url("serviceclsitems_2", 
		"URL=http://192.168.109.240/internal/api/access-manager/api/serviceclsitems?serviceref_id=9c9229c7-8a3f-4dfc-9cd0-966d5af19acc&limit=-1&loaderKey=none", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.109.240/internal/platform-admin-ui/services/services/9c9229c7-8a3f-4dfc-9cd0-966d5af19acc", 
		"Snapshot=t157.inf", 
		"Mode=HTML", 
		LAST);

	web_url("endpoints", 
		"URL=http://192.168.109.240/internal/api/access-manager/api/endpoints?serviceref_id=9c9229c7-8a3f-4dfc-9cd0-966d5af19acc&offset=0&limit=10&loaderKey=fe2d3ed2-7079-4eda-b86e-030d899fd80b", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.109.240/internal/platform-admin-ui/services/services/9c9229c7-8a3f-4dfc-9cd0-966d5af19acc", 
		"Snapshot=t158.inf", 
		"Mode=HTML", 
		LAST);

	web_url("endpoints_2", 
		"URL=http://192.168.109.240/internal/api/access-manager/api/endpoints?serviceref_id=9c9229c7-8a3f-4dfc-9cd0-966d5af19acc&offset=0&limit=10&order_by=asc(sysname)&loaderKey=9bbab50c-7cca-4d06-95a4-05c795ec75de", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.109.240/internal/platform-admin-ui/services/services/9c9229c7-8a3f-4dfc-9cd0-966d5af19acc", 
		"Snapshot=t159.inf", 
		"Mode=HTML", 
		LAST);

	web_url("endpoints_3", 
		"URL=http://192.168.109.240/internal/api/access-manager/api/endpoints?sysname=f&serviceref_id=9c9229c7-8a3f-4dfc-9cd0-966d5af19acc&offset=0&limit=10&order_by=asc(sysname)&loaderKey=9bbab50c-7cca-4d06-95a4-05c795ec75de", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.109.240/internal/platform-admin-ui/services/services/9c9229c7-8a3f-4dfc-9cd0-966d5af19acc", 
		"Snapshot=t160.inf", 
		"Mode=HTML", 
		LAST);

	web_url("endpoints_4", 
		"URL=http://192.168.109.240/internal/api/access-manager/api/endpoints?serviceref_id=9c9229c7-8a3f-4dfc-9cd0-966d5af19acc&offset=0&limit=10&order_by=asc(sysname)&loaderKey=9bbab50c-7cca-4d06-95a4-05c795ec75de", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.109.240/internal/platform-admin-ui/services/services/9c9229c7-8a3f-4dfc-9cd0-966d5af19acc", 
		"Snapshot=t161.inf", 
		"Mode=HTML", 
		LAST);

	web_url("endpoints_5", 
		"URL=http://192.168.109.240/internal/api/access-manager/api/endpoints?sysname=s&serviceref_id=9c9229c7-8a3f-4dfc-9cd0-966d5af19acc&offset=0&limit=10&order_by=asc(sysname)&loaderKey=9bbab50c-7cca-4d06-95a4-05c795ec75de", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.109.240/internal/platform-admin-ui/services/services/9c9229c7-8a3f-4dfc-9cd0-966d5af19acc", 
		"Snapshot=t162.inf", 
		"Mode=HTML", 
		LAST);

	web_url("endpoints_6", 
		"URL=http://192.168.109.240/internal/api/access-manager/api/endpoints?sysname=s&serviceref_id=9c9229c7-8a3f-4dfc-9cd0-966d5af19acc&offset=0&limit=10&loaderKey=fe2d3ed2-7079-4eda-b86e-030d899fd80b", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.109.240/internal/platform-admin-ui/services/services/9c9229c7-8a3f-4dfc-9cd0-966d5af19acc", 
		"Snapshot=t163.inf", 
		"Mode=HTML", 
		LAST);

	return 0;
}