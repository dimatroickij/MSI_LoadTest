Action1()
{

	web_set_user("loadUser123", 
		lr_unmask("600e7cb6e"), 
		"192.168.109.240:80");

	web_add_auto_header("DNT", 
		"1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("192.168.109.240", 
		"URL=http://192.168.109.240/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t20.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/assets/fonts/roboto/roboto.css", ENDITEM, 
		"Url=/styles.206c321067b55e6a4b75.css", ENDITEM, 
		"Url=/assets/fonts/fontawesome/css/all.css", ENDITEM, 
		"Url=/runtime.acf0dec4155e77772545.js", ENDITEM, 
		"Url=/polyfills.9cfb3f513e777138fb2c.js", ENDITEM, 
		"Url=/main.f260e358d880bc7956b9.js", ENDITEM, 
		"Url=/assets/images/logo.svg", ENDITEM, 
		LAST);

	web_url("configuration.json", 
		"URL=http://192.168.109.240//configurations/configuration.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.109.240/", 
		"Snapshot=t21.inf", 
		"Mode=HTML", 
		LAST);

	web_set_sockets_option("SSL_VERSION", "2&3");

	web_add_cookie("font_loaded=YSv1; DOMAIN=yandex.ru");

	web_add_cookie("_ym_uid=1573805452443910168; DOMAIN=yandex.ru");

	web_add_cookie("mda=0; DOMAIN=yandex.ru");

	web_add_cookie("yandexuid=8320292071573805450; DOMAIN=yandex.ru");

	web_add_cookie("yuidss=8320292071573805450; DOMAIN=yandex.ru");

	web_add_cookie("my=YwA=; DOMAIN=yandex.ru");

	web_add_cookie("Secure_session_id=1580114580.0.1.160061779.0.170906.49402.f7f5fe9e80c38883846057c915ff3935; DOMAIN=yandex.ru");

	web_add_cookie("_csrf=c47oTgAW6wEQRGVjGIfzK28R; DOMAIN=yandex.ru");

	web_add_cookie("gdpr=0; DOMAIN=yandex.ru");

	web_add_cookie("ymex=1896327882.yrts.1580967882#1900932202.yrtsi.1585572202; DOMAIN=yandex.ru");

	web_add_cookie("L=WnVGfUVde2haX0wHbERbAwBeYQ98cAp4EgcDKxoUDggnGRkD.1587546665.14211.39533.f96b7e9a736873a0ad3f29c40a2f5ba1; DOMAIN=yandex.ru");

	web_add_cookie("yandex_login=dimatroickij; DOMAIN=yandex.ru");

	web_add_cookie("yabs-sid=1075465931599135955; DOMAIN=yandex.ru");

	web_add_cookie("is_gdpr=0; DOMAIN=yandex.ru");

	web_add_cookie("is_gdpr_b=CKjwdxDrAygC; DOMAIN=yandex.ru");

	web_add_cookie("tuid=a:4d8369d5f7368b27e4e309838ccb63fdcdc698f85e3001482c74fa3c50100270; DOMAIN=yandex.ru");

	web_add_cookie("yandex_gid=20523; DOMAIN=yandex.ru");

	web_add_cookie("i=NkvK69WvNa4qIeZkcd+hTwGh+0M9gLwuU3QAcyn9aUOQ6vnFLKLFcdlYMv4VPdyr656SwObZuUbTp2XbGjxJ4ZMeCto=; DOMAIN=yandex.ru");

	web_add_cookie("hcxWnzbUzfz=1; DOMAIN=yandex.ru");

	web_add_cookie("bltsr=1; DOMAIN=yandex.ru");

	web_add_cookie("instruction=1; DOMAIN=yandex.ru");

	web_add_cookie("Session_id=3:1611408703.5.0.1574245027415:TCDCuQ:56.1|46814245.5608957.2.2:5608957|1130000034225354.5609733.2.2:5609733|229203.475964.FTdKX1aPT221iJuikaHdZ2zOCIU; DOMAIN=yandex.ru");

	web_add_cookie("sessionid2=3:1611408703.5.0.1574245027415:TCDCuQ:56.1|46814245.5608957.2.2:5608957|1130000034225354.5609733.2.2:5609733|229203.946113.CEZwh9zbcrnRS9rgwIeTkLtLJ50; DOMAIN=yandex.ru");

	web_add_cookie("_ym_isad=1; DOMAIN=yandex.ru");

	web_add_cookie("_ym_d=1611560677; DOMAIN=yandex.ru");

	web_add_cookie("yp=1618916268.nt.computers#1623882458.szm.1%3A1920x1080%3A1920x937#1902906665.udn.cDrQlNC80LjRgtGA0LjQuSDQotGA0L7QuNGG0LrQuNC5#1902906661.multib.1#1902906661.2fa.1#1643096981.p_sw.1611560980#1614152984.los.1#1614152984.losc.0#1612939175.ygu.1#1611919682.zmblt.1369#1611919682.zmbbr.chrome%3A87_0_4280_141; DOMAIN=yandex.ru");

	web_add_cookie("yabs-frequency=/5/00090000001t4PHU/rs-mS9K0000eFq7i-N9mb00002W_8UvDi72L0000A3z04tUmS9K0000fF-01orImS9K0000eFo2oTh1mbG0002a_80AsTh1mbG0002W_e4fti72L0000A3yW3NUmS9K0000eFq2_MR1mbG0002a_00NJSR1m000002W_863KFMq00000A3yWc4m-RG00000eFo0OTJrj000002W_O7vLi7000000A3yWrbYmS000000eFs00/; DOMAIN=yandex.ru");

	web_add_cookie("ys=udn.cDrQlNC80LjRgtGA0LjQuSDQotGA0L7QuNGG0LrQuNC5#wprid.1611560979781180-1638761530967817685100217-prestable-app-host-sas-web-yp-151#c_chck.310002396#musicchrome.0-0-4711111111111111111111111111111111; DOMAIN=yandex.ru");

	web_url("default.css", 
		"URL=http://192.168.109.240/themes/default.css", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://192.168.109.240/", 
		"Snapshot=t22.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=../assets/fonts/roboto/roboto-v20-latin_cyrillic-regular.woff2", "Referer=http://192.168.109.240/assets/fonts/roboto/roboto.css", ENDITEM, 
		"Url=../assets/fonts/roboto/roboto-v20-latin_cyrillic-700.woff2", "Referer=http://192.168.109.240/assets/fonts/roboto/roboto.css", ENDITEM, 
		"Url=../assets/fonts/roboto/roboto-v20-latin_cyrillic-500.woff2", "Referer=http://192.168.109.240/assets/fonts/roboto/roboto.css", ENDITEM, 
		"Url=../assets/fonts/fontawesome/webfonts/fa-light-300.woff2", "Referer=http://192.168.109.240/assets/fonts/fontawesome/css/all.css", ENDITEM, 
		"Url=https://yandex.ru/clck/click/dtype=elduse/path=tech.yaelements.dayuse/vars=-dayuse=437,-bro=chrome,-productname=weatherchrome,-ver=8-22-3,-ui=%7B09DD5623-D941-75FB-FF65-BEE4E3B516BA%7D,-brandID=yandex,-clid1=2231762/slots=0,0,0/*", "Referer=", ENDITEM, 
		LAST);

	/*Connection ID 0 received buffer WebSocketReceive0*/

	/*Connection ID 1 received buffer WebSocketReceive1*/

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("platform-admin-ui", 
		"URL=http://192.168.109.240/internal/platform-admin-ui", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://192.168.109.240/", 
		"Snapshot=t23.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=platform-admin-ui/vendor.6597440179a1a361a262.js", "Referer=http://192.168.109.240/internal/platform-admin-ui/", ENDITEM, 
		"Url=platform-admin-ui/main.a113815411d365738099.js", "Referer=http://192.168.109.240/internal/platform-admin-ui/", ENDITEM, 
		"Url=platform-admin-ui/runtime.b9759be94b30ae2a33e0.js", "Referer=http://192.168.109.240/internal/platform-admin-ui/", ENDITEM, 
		"Url=platform-admin-ui/polyfills.cfc88ca87321ca8e8ec7.js", "Referer=http://192.168.109.240/internal/platform-admin-ui/", ENDITEM, 
		"Url=platform-admin-ui/styles.934e1211369de65239dc.css", "Referer=http://192.168.109.240/internal/platform-admin-ui/", ENDITEM, 
		"Url=platform-admin-ui/themes/default/theme.css", "Referer=http://192.168.109.240/internal/platform-admin-ui/", ENDITEM, 
		"Url=platform-admin-ui/common.f69f8709d30822f7fa9b.js", "Referer=http://192.168.109.240/internal/platform-admin-ui/", ENDITEM, 
		"Url=platform-admin-ui/25.d6516b342757454e33d9.js", "Referer=http://192.168.109.240/internal/platform-admin-ui/", ENDITEM, 
		"Url=platform-admin-ui/11.c02acfdbffc46255fbeb.js", "Referer=http://192.168.109.240/internal/platform-admin-ui/", ENDITEM, 
		"Url=platform-admin-ui/themes/default/images/default-spinner.svg", "Referer=http://192.168.109.240/internal/platform-admin-ui/", ENDITEM, 
		"Url=platform-admin-ui/2.1891a41e4a0f084937e0.js", "Referer=http://192.168.109.240/internal/platform-admin-ui/", ENDITEM, 
		"Url=platform-admin-ui/3.c4a949ba0a212384bfec.js", "Referer=http://192.168.109.240/internal/platform-admin-ui/", ENDITEM, 
		"Url=platform-admin-ui/4.842d7f0dccf6876ffcfc.js", "Referer=http://192.168.109.240/internal/platform-admin-ui/", ENDITEM, 
		"Url=platform-admin-ui/12.416582247b9526f72da2.js", "Referer=http://192.168.109.240/internal/platform-admin-ui/", ENDITEM, 
		LAST);

	web_url("configuration.json_2", 
		"URL=http://192.168.109.240/internal/platform-admin-ui//configurations/configuration.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.109.240/internal/platform-admin-ui/", 
		"Snapshot=t24.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/internal/platform-admin-ui/themes/default/fonts/ptsans.css", "Referer=http://192.168.109.240/internal/platform-admin-ui/themes/default/theme.css", ENDITEM, 
		"Url=/internal/platform-admin-ui/themes/default/fonts/ptsans/ptsansbold.woff2", "Referer=http://192.168.109.240/internal/platform-admin-ui/themes/default/fonts/ptsans.css", ENDITEM, 
		"Url=/internal/platform-admin-ui/themes/default/fonts/ptsans/ptsans.woff2", "Referer=http://192.168.109.240/internal/platform-admin-ui/themes/default/fonts/ptsans.css", ENDITEM, 
		LAST);

	/*Possible OAUTH authorization was detected. It is recommended to correlate the authorization parameters.*/

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("login", 
		"URL=http://192.168.109.240/internal/authutil/auth/login?returnUrl=http://192.168.109.240/internal/platform-admin-ui/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://192.168.109.240/internal/platform-admin-ui/", 
		"Snapshot=t25.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=../runtime.912d0e53e8715a3eb26c.js", "Referer=http://192.168.109.240/internal/authutil/auth/login?returnUrl=http://192.168.109.240/internal/platform-admin-ui/", ENDITEM, 
		"Url=../styles.441d4b6bb0d262a7576b.css", "Referer=http://192.168.109.240/internal/authutil/auth/login?returnUrl=http://192.168.109.240/internal/platform-admin-ui/", ENDITEM, 
		"Url=../polyfills.adc7784a1251bb58b248.js", "Referer=http://192.168.109.240/internal/authutil/auth/login?returnUrl=http://192.168.109.240/internal/platform-admin-ui/", ENDITEM, 
		"Url=../main.81b056e6adee1957fff7.js", "Referer=http://192.168.109.240/internal/authutil/auth/login?returnUrl=http://192.168.109.240/internal/platform-admin-ui/", ENDITEM, 
		LAST);

	web_url("configuration.json_3", 
		"URL=http://192.168.109.240/internal/authutil//configurations/configuration.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.109.240/internal/authutil/auth/login?returnUrl=http://192.168.109.240/internal/platform-admin-ui/", 
		"Snapshot=t26.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/internal/authutil/themes/default/theme.css", "Referer=http://192.168.109.240/internal/authutil/auth/login?returnUrl=http://192.168.109.240/internal/platform-admin-ui/", ENDITEM, 
		"Url=/internal/authutil/themes/default/images/default-logo.svg", "Referer=http://192.168.109.240/internal/authutil/", ENDITEM, 
		"Url=/internal/authutil/themes/default/fonts/roboto/roboto-v20-latin_cyrillic-500.woff2", "Referer=http://192.168.109.240/internal/authutil/themes/default/theme.css", ENDITEM, 
		"Url=/internal/authutil/themes/default/fonts/roboto/roboto-v20-latin_cyrillic-regular.woff2", "Referer=http://192.168.109.240/internal/authutil/themes/default/theme.css", ENDITEM, 
		"Url=/internal/authutil/5.aaabecb7b2435b372cd5.js", "Referer=http://192.168.109.240/internal/authutil/auth/login?returnUrl=http://192.168.109.240/internal/platform-admin-ui/", ENDITEM, 
		"Url=/internal/authutil/MaterialIcons-Regular.12a47ed5fd5585f0f422.woff2", "Referer=http://192.168.109.240/internal/authutil/styles.441d4b6bb0d262a7576b.css", ENDITEM, 
		LAST);

	return 0;
}